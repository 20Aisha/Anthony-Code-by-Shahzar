export { default as HomeScreen } from "./Pages/Home/Home";
export { default as MGALink } from "./Pages/MGALink/MGALink";
// export { default as  } from "./Pages";
